<footer id="fh5co-footer" role="contentinfo">

		<div class="container">
			<div class="col-md-3 col-sm-9 col-sm-push-0 ">
				<h3>PKM</h3>
				<p>PKM adalah program Kreativitas mahasiswa dalam mengembangan suatu ide dan mengajukan proposal penelitian</p>
			</div>
			<div class="col-md-4 col-md-push-1 col-sm-9 col-sm-push-0 col-xs-9 col-xs-push-0">
				<h3>BSI GROUP</h3>
				<ul class="float">
					<li><a href="<?php echo base_url().'portfolio'?>">BINA SARANA INFORMATIKA</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">UNIVERSITAS BSI BANDUNG</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">STMIK NUSA MANDIRI JAKARTA</a></li>
				</ul>
				

			</div>
			<div class="col-md-2 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>INFORMASI BSI</h3>
				<ul class="float">
					<li><a href="<?php echo base_url().'portfolio'?>">PMB BSI</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">BEC</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">BCC</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">PKM</a></li>
				</ul>
			</div>

			<div class="col-md-2 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>Sosial Media</h3>
				<ul class="fh5co-social">
					<li><a href="#"><i class="icon-twitter"></i></a></li>
					<li><a href="#"><i class="icon-facebook"></i></a></li>
					<li><a href="#"><i class="icon-google-plus"></i></a></li>
					<li><a href="#"><i class="icon-instagram"></i></a></li>
				</ul>
			</div>


			<div class="col-md-12 fh5co-copyright text-center">
				<p>&copy; 2018 by Hermanto</a>. All Rights Reserved.</p>
			</div>

		</div>
	</footer>
